#include <Arduino.h>
#include <Wire.h>
#include "UniProto.h"
//#include "mod_adc.h"
//#include "mod_motors.h"
//#include "mod_psd.h"
//#include "mod_bldc.h"
#include "mod_adns2610.h"
UniProto proto(Serial, "OpticalMouse");
//AdcModule adc(AdcModule::defaultUno());
//BldcModule bldc(BldcModule::defaultUno());
//PsdModule psd(PsdModule::defaultUnoA0());
//DualMotorModule motors(DualMotorModule::defaultUno());
Adns2610Module adns(Adns2610Module::defaultUno());
void setup() {
  Serial.begin(115200);
  //Wire.begin();
  //Wire.setClock(400000);
  proto.begin();
  //bldc.registerWith(proto);
  adns.registerWith(proto);
  //psd.registerWith(proto);
  //adc.registerWith(proto);
  //motors.registerWith(proto);
  //i2cScan();  // uncomment once for bring-up
}
void loop() {
  proto.tick();
  //motors.poll();     // control loop
  //bldc.poll();
}

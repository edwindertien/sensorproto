#!/usr/bin/env python3
import argparse
import struct
import time

import serial
import numpy as np
import matplotlib.pyplot as plt


SYNC0 = 0xAA
SYNC1 = 0x55


def log(msg):
    print(msg, flush=True)


def write_cmd(ser: serial.Serial, s: str):
    if not s.endswith("\n"):
        s += "\n"
    log(f">>> {s.strip()}")
    ser.write(s.encode("ascii", errors="ignore"))
    ser.flush()


def read_exact(ser: serial.Serial, n: int) -> bytes:
    b = ser.read(n)
    if len(b) != n:
        raise TimeoutError(f"timeout: wanted {n} bytes got {len(b)}")
    return b


def find_sync(ser: serial.Serial, timeout_s=2.0) -> None:
    """Find 0xAA 0x55 in the byte stream."""
    t0 = time.time()
    prev = None
    while True:
        b = ser.read(1)
        if b:
            cur = b[0]
            if prev == SYNC0 and cur == SYNC1:
                return
            prev = cur
        if time.time() - t0 > timeout_s:
            raise TimeoutError("Timed out waiting for 0xAA55 sync")


def read_packet(ser: serial.Serial):
    """
    UniProto binBegin:
      0xAA 0x55
      streamId (u8)
      flags (u8) bit0 = timestamp
      payloadLen (u16 LE)
      [timestamp ms u32 LE] if flags&1
      payload (payloadLen bytes)
    """
    find_sync(ser)
    hdr = read_exact(ser, 1 + 1 + 2)  # streamId, flags, payloadLen
    stream_id = hdr[0]
    flags = hdr[1]
    payload_len = struct.unpack("<H", hdr[2:4])[0]

    ts_ms = None
    if flags & 0x01:
        ts_ms = struct.unpack("<I", read_exact(ser, 4))[0]

    payload = read_exact(ser, payload_len)
    return stream_id, flags, ts_ms, payload


def parse_adns_chunk(payload: bytes):
    """
    payload:
      u16 frame_id
      u16 w
      u16 h
      u16 offset
      u16 count
      bytes[count]
    """
    if len(payload) < 10:
        return None
    frame_id, w, h, off, count = struct.unpack("<HHHHH", payload[:10])
    data = payload[10:]
    if len(data) != count:
        return None
    return frame_id, w, h, off, data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", required=True)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--stream", type=int, default=7)
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--flip_x", action="store_true")
    ap.add_argument("--flip_y", action="store_true")
    ap.add_argument("--continuous", action="store_true",
                    help="automatically request new frames (sends !adns.capture:1 after each completed frame)")
    args = ap.parse_args()

    log(f"[INFO] Opening {args.port} @ {args.baud}")
    ser = serial.Serial(args.port, args.baud, timeout=0.5)
    time.sleep(1.5)
    ser.reset_input_buffer()
    ser.reset_output_buffer()
    log("[INFO] Port open.")

    # Put device in binary + enable stream
    write_cmd(ser, "!format:bin")
    write_cmd(ser, f"!stream:{args.stream}")

    # Request one frame to start
    write_cmd(ser, "!adns.capture:1")

    plt.ion()
    fig, ax = plt.subplots()
    img = None
    ax.set_title("ADNS2610 18x18 (0..63)")
    ax.set_xlabel("x")
    ax.set_ylabel("y")

    cur_id = None
    w = 18
    h = 18
    buf = None
    mask = None

    while True:
        try:
            sid, flags, ts_ms, payload = read_packet(ser)
        except TimeoutError:
            continue

        if sid != args.stream:
            continue

        chunk = parse_adns_chunk(payload)
        if not chunk:
            continue

        frame_id, cw, ch, off, data = chunk

        if (cur_id != frame_id) or (buf is None) or (cw != w) or (ch != h):
            cur_id = frame_id
            w, h = cw, ch
            buf = np.zeros(w * h, dtype=np.uint8)
            mask = np.zeros(w * h, dtype=np.uint8)
            log(f"[FRAME] id={frame_id} {w}x{h} ts={ts_ms}")

        n = len(data)
        if off + n <= buf.size:
            buf[off:off+n] = np.frombuffer(data, dtype=np.uint8)
            mask[off:off+n] = 1

        if mask is not None and mask.all():
            img2 = buf.reshape((h, w)).astype(np.float32) / 63.0
            if args.flip_y:
                img2 = np.flipud(img2)
            if args.flip_x:
                img2 = np.fliplr(img2)

            if img is None:
                img = ax.imshow(img2, interpolation="nearest")
                fig.colorbar(img, ax=ax, fraction=0.046, pad=0.04)
            else:
                img.set_data(img2)

            ax.set_title(f"ADNS2610 frame {frame_id}" + (f"  t={ts_ms}ms" if ts_ms is not None else ""))
            fig.canvas.draw()
            fig.canvas.flush_events()

            if args.once:
                break

            if args.continuous:
                # request next capture
                write_cmd(ser, "!adns.capture:1")
            else:
                # otherwise just sit on the last frame
                pass

    ser.close()
    log("[INFO] Closed.")


if __name__ == "__main__":
    main()
